<#
.SYNOPSIS
  Read-only per-host deep dive for ESX 9.x / VCF 9.1.x readiness: boot media, security posture, third-party VIBs, NIC driver+firmware, DNS (KB 425102), NTP, certificates, vLCM image/HSM.
.EXAMPLE
  .\Collect-VcfHostDeepDive.ps1 -VCenter vc01.corp.local,vc02.corp.local -OutDir C:\vcfr
.NOTES
  Run alongside Collect-VcfReadiness.ps1. Needs PowerCLI 13.x and a read-only vCenter account with host config read. Uses ESXCLI v2 list/get calls only.
  Output: pcli_boot.csv, pcli_security.csv, pcli_vibs.csv, pcli_nicfw.csv, pcli_dns.csv, pcli_ntp.csv, pcli_images.csv, pcli_hsm.csv, pcli_vsandisks.csv
#>
param([Parameter(Mandatory)][string[]]$VCenter, [string]$OutDir = ".\vcfr-collect", [pscredential]$Credential)
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -Scope Session | Out-Null
$boot=@();$sec=@();$vib=@();$nicfw=@();$dns=@();$ntp=@();$img=@();$hsm=@();$vsd=@()
foreach ($vcName in $VCenter) {
  Write-Host "== $vcName"
  try { $vc = if ($Credential) { Connect-VIServer $vcName -Credential $Credential -ErrorAction Stop } else { Connect-VIServer $vcName -ErrorAction Stop } } catch { Write-Warning "connect failed: $_"; continue }
  # vLCM: image per cluster + registered hardware support managers (best effort via CIS REST)
  try { $cis = Connect-CisServer $vcName -Credential $Credential -ErrorAction Stop
        foreach ($m in (Get-CisService -Name 'com.vmware.esx.settings.hardware_support.managers' -Server $cis).list()) {
          $hsm += [pscustomobject]@{vc=$vcName;Manager=$m.name;Vendor=$m.vendor;Version=$m.version;Url=$m.url} } } catch {}
  foreach ($c in Get-Cluster -Server $vc) {
    try { $sw = (Get-CisService -Name 'com.vmware.esx.settings.clusters.software' -ErrorAction Stop).get($c.ExtensionData.MoRef.Value)
          $img += [pscustomobject]@{vCenter=$vcName;Cluster=$c.Name;BaseImage=$sw.base_image.version;AddOn=$sw.add_on.name;AddOnVersion=$sw.add_on.version;HardwareSupport=($sw.hardware_support.PSObject.Properties.Name -join ';')} } catch {
          $img += [pscustomobject]@{vCenter=$vcName;Cluster=$c.Name;BaseImage='baseline-or-unavailable';AddOn='';AddOnVersion='';HardwareSupport=''} }
    foreach ($d in (Get-VsanDiskGroup -Cluster $c -ErrorAction SilentlyContinue)) {
      foreach ($disk in $d.ExtensionData.Ssd + $d.ExtensionData.NonSsd) { $vsd += [pscustomobject]@{vCenter=$vcName;Cluster=$c.Name;Host=$d.VMHost.Name;DiskGroup=$d.Name;Disk=$disk.CanonicalName;Version=$disk.VsanDiskInfo.FormatVersion;Vendor=$disk.Vendor;Model=$disk.Model} } }
  }
  foreach ($h in Get-VMHost -Server $vc | Where-Object ConnectionState -eq 'Connected') {
    $hn = $h.Name; $cl = $h.Parent.Name
    # DNS forward/reverse
    $fwd=$false;$rev=$false;$ip=''
    try { $ip=([Net.Dns]::GetHostAddresses($hn) | Select-Object -First 1).IPAddressToString; $fwd=$true; $rev=([Net.Dns]::GetHostEntry($ip).HostName -ieq $hn) } catch {}
    $dns += [pscustomobject]@{vCenter=$vcName;Cluster=$cl;Host=$hn;InventoryNameIsFqdn=($hn -match '\.');ForwardOk=$fwd;ReverseOk=$rev;ResolvedIP=$ip}
    $ntpSvc = Get-VMHostService -VMHost $h | Where-Object Key -eq 'ntpd'
    $ntp += [pscustomobject]@{vCenter=$vcName;Cluster=$cl;Host=$hn;NtpServers=((Get-VMHostNtpServer -VMHost $h) -join ';');NtpRunning=$ntpSvc.Running;NtpPolicy=$ntpSvc.Policy}
    try { $x = Get-EsxCli -VMHost $h -V2
      # boot media
      foreach ($dv in $x.storage.core.device.list.Invoke()) {
        if ($dv.IsBootDevice -eq $true -or $dv.IsBootUSBDevice -eq $true) {
          $boot += [pscustomobject]@{vCenter=$vcName;Cluster=$cl;Host=$hn;Device=$dv.Device;Vendor=$dv.Vendor;Model=$dv.Model;SizeMB=$dv.Size;IsBootUSB=$dv.IsBootUSBDevice;IsSSD=$dv.IsSSD;IsLocal=$dv.IsLocal;IsRemovable=$dv.IsRemovable} } }
      # security posture
      $enc = $x.system.settings.encryption.get.Invoke(); $tb=$null; try { $tb = $x.hardware.trustedboot.get.Invoke() } catch {}
      $tpm=$null; try { $tpm = $x.hardware.tpm.get.Invoke() } catch {}
      $sec += [pscustomobject]@{vCenter=$vcName;Cluster=$cl;Host=$hn;EncryptionMode=$enc.Mode;RequireSecureBoot=$enc.RequireSecureBoot;RequireExecInstalledOnly=$enc.RequireExecutablesOnlyFromInstalledVIBs;
          TpmPresent=$tpm.Present;DrtmEnabled=$tb.DRTMEnabled;TpmVersion=$tb.TPMVersion;LockdownMode=$h.ExtensionData.Config.LockdownMode;SshRunning=((Get-VMHostService -VMHost $h | Where-Object Key -eq 'TSM-SSH').Running)}
      # third-party VIBs (drivers, agents) - upgrade-relevant
      foreach ($v in $x.software.vib.list.Invoke()) { if ($v.Vendor -notmatch '^VMware|VMW$') {
          $vib += [pscustomobject]@{vCenter=$vcName;Cluster=$cl;Host=$hn;Name=$v.Name;Version=$v.Version;Vendor=$v.Vendor;AcceptanceLevel=$v.AcceptanceLevel;InstallDate=$v.InstallDate} } }
      # NIC driver + firmware
      foreach ($n in $x.network.nic.list.Invoke()) { $g = $x.network.nic.get.Invoke(@{nicname=$n.Name})
          $nicfw += [pscustomobject]@{vCenter=$vcName;Cluster=$cl;Host=$hn;Nic=$n.Name;Description=$n.Description;SpeedMbps=$n.LinkSpeed;Driver=$g.DriverInfo.Driver;DriverVersion=$g.DriverInfo.Version;Firmware=$g.DriverInfo.FirmwareVersion;PCI=$n.PCIDevice} }
    } catch { Write-Warning "esxcli failed on $hn : $_" }
  }
  Disconnect-VIServer $vcName -Confirm:$false -ErrorAction SilentlyContinue
}
$map=@{pcli_boot=$boot;pcli_security=$sec;pcli_vibs=$vib;pcli_nicfw=$nicfw;pcli_dns=$dns;pcli_ntp=$ntp;pcli_images=$img;pcli_hsm=$hsm;pcli_vsandisks=$vsd}
foreach ($k in $map.Keys) { if (@($map[$k]).Count) { $map[$k] | Export-Csv (Join-Path $OutDir "$k.csv") -NoTypeInformation -Encoding UTF8; Write-Host "  wrote $k.csv ($(@($map[$k]).Count) rows)" } else { Write-Host "  no data for $k" } }
