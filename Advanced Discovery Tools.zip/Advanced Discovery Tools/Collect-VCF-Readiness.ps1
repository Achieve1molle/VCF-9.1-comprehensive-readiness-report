<#
.SYNOPSIS
  Read-only PowerCLI collector that fills the gaps RVTools cannot see for a VCF 9.1 readiness assessment.
.DESCRIPTION
  Produces CSV files in -OutDir. Every file is optional - the report builder marks anything missing as a
  "data gap" instead of failing. Nothing is changed in the environment (Get-* / read-only API calls only).
.EXAMPLE
  .\Collect-VcfReadiness.ps1 -VCenter vc01.corp.local,vc02.corp.local -OutDir C:\vcfr -IncludePci
.NOTES
  Requires VMware.PowerCLI 13.x. Use a read-only vCenter account. ESXCLI calls (CPU family, PCI IDs) need
  the account to have Host.Config.* read privileges and hosts to be connected.
#>
param(
  [Parameter(Mandatory)][string[]]$VCenter,
  [string]$OutDir = ".\vcfr-collect",
  [switch]$IncludePci,          # per-host PCI IDs (VID/DID/SVID/SSID) for a definitive BCG check - slower
  [switch]$SkipVmFeatures,      # skip the per-VM device scan
  [switch]$VmFeaturesOnly,      # fast mode: ONLY VM encryption for all VMs plus a capped detailed feature sample - minutes instead of hours
  [pscredential]$Credential,       # optional shared credential; otherwise prompt separately for every vCenter
  [ValidateRange(1,500)][int]$VmFeatureSampleLimit = 50
)
$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -Scope Session | Out-Null

function Save($name, $rows) {
  if ($rows -and @($rows).Count -gt 0) { $rows | Export-Csv -NoTypeInformation -Path (Join-Path $OutDir $name) -Encoding UTF8
    Write-Host ("  wrote {0} ({1} rows)" -f $name, @($rows).Count) } else { Write-Host "  no data for $name" }
}
$vcInfo=@(); $clu=@(); $hostHw=@(); $vmk=@(); $vds=@(); $vmf=@(); $vme=@(); $vmCoverage=@(); $ext=@(); $pci=@(); $vsan=@(); $ds=@()

foreach ($vcName in $VCenter) {
  Write-Host "== $vcName"
  $vcCredential = if ($Credential) { $Credential } else { Get-Credential -Message "Credential for $vcName" -UserName 'administrator@vsphere.local' }
  try { $vc = Connect-VIServer $vcName -Credential $vcCredential -ErrorAction Stop }
  catch { Write-Warning "Cannot connect to $vcName : $_"; continue }
  $about = $vc.ExtensionData.Content.About

  if (-not $VmFeaturesOnly) {
  # ---- extensions / solutions registered (NSX, SRM, VR, Horizon, HX, vRops...) ----
  $nsxReg=$false
  try { $em = Get-View $vc.ExtensionData.Content.ExtensionManager
        foreach ($e in $em.ExtensionList) {
          if ($e.Key -match 'nsx') { $nsxReg=$true }
          $ext += [pscustomobject]@{vCenter=$vcName;Key=$e.Key;Label=$e.Description.Label;Version=$e.Version;Company=$e.Company} } } catch {}

  # ---- VCHA / Supervisor (best effort via CIS REST) ----
  $vcha='unknown'; $supervisor=@{}
  try { $s = Connect-CisServer $vcName -Credential $Credential -ErrorAction Stop
        try { $v = (Get-CisService -Name 'com.vmware.vcenter.vcha.cluster' -Server $s).get($false); $vcha = $v.mode } catch { $vcha='not-configured-or-unavailable' }
        try { foreach ($c in (Get-CisService -Name 'com.vmware.vcenter.namespace_management.clusters' -Server $s).list()) { $supervisor[$c.cluster]=$c.config_status } } catch {} } catch {}

  # ---- Embedded linked mode: count of vCenters visible in the same SSO domain ----
  $elm = (Get-View -Server $vc ServiceInstance -ErrorAction SilentlyContinue) | Out-Null
  $vcInfo += [pscustomobject]@{vCenter=$vcName;Version=$about.Version;Build=$about.Build;FullName=$about.FullName;
              InstanceUuid=$about.InstanceUuid;NsxRegistered=$nsxReg;VCHA=$vcha;LinkedVCenters=($global:DefaultVIServers.Count-1)}

  # ---- clusters ----
  foreach ($c in Get-Cluster -Server $vc) {
    $cx=$c.ExtensionData; $vsc=$cx.ConfigurationEx.VsanConfigInfo
    $mode='unknown'
    try { $cis = Get-CisService -Name 'com.vmware.esx.settings.clusters.software' -ErrorAction Stop
          try { $null=$cis.get($c.ExtensionData.MoRef.Value); $mode='image' } catch { $mode='baseline' } } catch {}
    $esa=$null; $dedup=$null; $comp=$null; $stretch=$null
    if ($vsc.Enabled) {
      $esa=$vsc.VsanEsaEnabled
      try { $de=$vsc.DataEfficiencyConfig; $dedup=$de.DedupEnabled; $comp=$de.CompressionEnabled } catch {}
      try { $stretch=(Get-VsanClusterConfiguration -Cluster $c -ErrorAction Stop).StretchedClusterEnabled } catch {}
      $vsan += [pscustomobject]@{vCenter=$vcName;Cluster=$c.Name;VsanEnabled=$true;ESA=$esa;Dedup=$dedup;Compression=$comp;Stretched=$stretch}
    }
    $clu += [pscustomobject]@{vCenter=$vcName;Cluster=$c.Name;Hosts=(@(Get-VMHost -Location $c)).Count;DrsEnabled=$c.DrsEnabled;DrsLevel=$c.DrsAutomationLevel;
        HAEnabled=$c.HAEnabled;EVC=$c.EVCMode;LifecycleMode=$mode;VsanEnabled=[bool]$vsc.Enabled;VsanESA=$esa;
        SupervisorStatus=$supervisor[$c.ExtensionData.MoRef.Value]}
  }

  # ---- datastores (type + vVol / vSAN) ----
  foreach ($d in Get-Datastore -Server $vc) {
    $ds += [pscustomobject]@{vCenter=$vcName;Name=$d.Name;Type=$d.Type;CapacityGB=[math]::Round($d.CapacityGB,1);FreeGB=[math]::Round($d.FreeGB,1);
        VmfsVersion=$d.FileSystemVersion;HostCount=@($d.ExtensionData.Host).Count}
  }

  # ---- distributed switches ----
  foreach ($d in Get-VDSwitch -Server $vc) {
    $vds += [pscustomobject]@{vCenter=$vcName;Name=$d.Name;Version=$d.Version;Mtu=$d.Mtu;NumUplinkPorts=$d.NumUplinkPorts;
        HostCount=@($d.ExtensionData.Summary.HostMember).Count;LacpEnabled=($d.ExtensionData.Config.LacpApiVersion -ne $null);
        Vendor=$d.Vendor}
  }

  # ---- hosts: hardware, CPU family/model/stepping, FQDN, vmk adapters, PCI ----
  foreach ($h in Get-VMHost -Server $vc) {
    $hx=$h.ExtensionData; $cpuFam=$null;$cpuMod=$null;$cpuStep=$null; $tpm=$null
    if ($h.ConnectionState -eq 'Connected') {
      try { $x=Get-EsxCli -VMHost $h -V2; $cl=$x.hardware.cpu.list.Invoke() | Select-Object -First 1
            $cpuFam=$cl.Family;$cpuMod=$cl.Model;$cpuStep=$cl.Stepping
            try { $tpm=($x.hardware.tpm.get.Invoke()).Present } catch {}
            if ($IncludePci) {
              foreach ($p in $x.hardware.pci.list.Invoke()) {
                $cls=[string]$p.DeviceClassName
                if ($p.ModuleName -and ($cls -match 'Network|Ethernet|Fibre|Mass storage|RAID|SCSI|NVM|SATA|SAS|Serial Attached')) {
                  $pci += [pscustomobject]@{vCenter=$vcName;Host=$h.Name;Cluster=$h.Parent.Name;Device=$p.DeviceName;Vendor=$p.VendorName;
                    VID=('{0:x4}' -f $p.VendorID);DID=('{0:x4}' -f $p.DeviceID);SVID=('{0:x4}' -f $p.SubVendorID);SSID=('{0:x4}' -f $p.SubDeviceID);
                    Driver=$p.ModuleName;Class=$cls} } } }
          } catch { Write-Warning "esxcli failed on $($h.Name): $_" }
    }
    $hostHw += [pscustomobject]@{vCenter=$vcName;Host=$h.Name;InventoryNameIsFqdn=($h.Name -match '\.');Cluster=$h.Parent.Name;
        Vendor=$hx.Hardware.SystemInfo.Vendor;Model=$hx.Hardware.SystemInfo.Model;Bios=$hx.Hardware.BiosInfo.BiosVersion;
        CpuModel=$hx.Hardware.CpuPkg[0].Description;CpuFamily=$cpuFam;CpuModelNum=$cpuMod;CpuStepping=$cpuStep;Tpm=$tpm;
        EsxVersion=$h.Version;EsxBuild=$h.Build;Connection=$h.ConnectionState;LockdownMode=$hx.Config.LockdownMode}
    foreach ($n in Get-VMHostNetworkAdapter -VMHost $h -VMKernel) {
      $onVds = [bool]$n.ExtensionData.Spec.DistributedVirtualPort
      $vmk += [pscustomobject]@{vCenter=$vcName;Host=$h.Name;Cluster=$h.Parent.Name;Device=$n.Name;PortGroup=$n.PortGroupName;OnVds=$onVds;
          IP=$n.IP;Dhcp=$n.DhcpEnabled;Mtu=$n.Mtu;Mgmt=$n.ManagementTrafficEnabled;vMotion=$n.VMotionEnabled;FT=$n.FaultToleranceLoggingEnabled;
          vSAN=$n.VsanTrafficEnabled;Provisioning=$n.ProvisioningEnabled}
    }
  }

  }  # end of -not VmFeaturesOnly sections

  # ---- VM encryption for every non-template VM; no manual vSphere UI export required ----
  $encProps='Name','Runtime.PowerState','Config.Template','Config.Uuid','Config.KeyId','Config.Hardware.Device','Runtime.Host','Parent'
  $hostMap=@{}; Get-VMHost -Server $vc | ForEach-Object { $hostMap[$_.ExtensionData.MoRef.Value]=$_ }
  $allVmViews = @(Get-View -Server $vc -ViewType VirtualMachine -Property $encProps | Where-Object { -not $_.Config.Template } | Sort-Object Name,{$_.Config.Uuid})
  foreach ($v in $allVmViews) {
    $dev=@($v.Config.Hardware.Device)
    $encDisks=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualDisk] -and $_.Backing.KeyId }).Count
    $h=if($v.Runtime.Host){$hostMap[$v.Runtime.Host.Value]}else{$null}
    $provider=''
    try { if($v.Config.KeyId -and $v.Config.KeyId.ProviderId){$provider=$v.Config.KeyId.ProviderId.Id} } catch {}
    $isEncrypted=[bool]$v.Config.KeyId -or ($encDisks -gt 0)
    $vme += [pscustomobject]@{
      vCenter=$vcName;VM=$v.Name;Uuid=$v.Config.Uuid;Cluster=$(if($h){$h.Parent.Name});Host=$(if($h){$h.Name});
      Encryption=$(if($isEncrypted){'Yes'}else{'No'});VmConfigEncrypted=[bool]$v.Config.KeyId;
      EncryptedDisks=$encDisks;EncryptionKeyProvider=$provider;PowerState=$v.Runtime.PowerState
    }
  }

  # ---- Detailed VM feature scan: deterministic sample of no more than 50 VMs per vCenter ----
  if (-not $SkipVmFeatures) {
    $selectedIds=@($allVmViews | Select-Object -First $VmFeatureSampleLimit | ForEach-Object {$_.Config.Uuid})
    $props='Name','Runtime.PowerState','Config.Template','Config.Uuid','Config.KeyId','Config.Flags','Config.Hardware.Device','Config.GuestId','Config.GuestFullName','Config.Version','Config.Firmware','Config.BootOptions','Config.NestedHVEnabled','Runtime.Host','Runtime.FaultToleranceState','Parent'
    $detailed=@(Get-View -Server $vc -ViewType VirtualMachine -Property $props | Where-Object {$selectedIds -contains $_.Config.Uuid} | Sort-Object Name,{$_.Config.Uuid})
    foreach ($v in $detailed) {
      $dev=@($v.Config.Hardware.Device)
      $encDisks=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualDisk] -and $_.Backing.KeyId }).Count
      $h=if($v.Runtime.Host){$hostMap[$v.Runtime.Host.Value]}else{$null}
      $provider=''; try { if($v.Config.KeyId -and $v.Config.KeyId.ProviderId){$provider=$v.Config.KeyId.ProviderId.Id} } catch {}
      $vmf += [pscustomobject]@{vCenter=$vcName;VM=$v.Name;Uuid=$v.Config.Uuid;Cluster=$(if($h){$h.Parent.Name});
        VmEncrypted=([bool]$v.Config.KeyId -or ($encDisks -gt 0));Encryption=$(if($v.Config.KeyId -or $encDisks -gt 0){'Yes'}else{'No'});EncryptionKeyProvider=$provider;EncryptedDisks=$encDisks;
        vTPM=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualTPM] }).Count -gt 0;
        vNVMeController=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualNVMEController] }).Count;
        VBS=[bool]$v.Config.Flags.VbsEnabled;IommuEnabled=[bool]$v.Config.Flags.VvtdEnabled;NestedHV=[bool]$v.Config.NestedHVEnabled;
        Firmware=$v.Config.Firmware;EfiSecureBoot=[bool]$v.Config.BootOptions.EfiSecureBootEnabled;PowerState=$v.Runtime.PowerState;GuestFullName=$v.Config.GuestFullName;
        PciPassthrough=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualPCIPassthrough] }).Count;
        SriovNic=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualSriovEthernetCard] }).Count;
        UsbPassthrough=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualUSB] }).Count;
        HostDeviceBackedCdFloppy=@($dev | Where-Object { ($_ -is [VMware.Vim.VirtualCdrom] -or $_ -is [VMware.Vim.VirtualFloppy]) -and ($_.Backing -is [VMware.Vim.VirtualCdromAtapiBackingInfo] -or $_.Backing -is [VMware.Vim.VirtualFloppyDeviceBackingInfo]) }).Count;
        SerialParallelHostBacked=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualSerialPort] -or $_ -is [VMware.Vim.VirtualParallelPort] }).Count;
        PvrdmaNic=@($dev | Where-Object { $_ -is [VMware.Vim.VirtualVmxnet3Vrdma] }).Count;
        FaultTolerance=$v.Runtime.FaultToleranceState;HwVersion=$v.Config.Version;GuestId=$v.Config.GuestId}
    }
    $vmCoverage += [pscustomobject]@{vCenter=$vcName;TotalNonTemplateVMs=$allVmViews.Count;EncryptionRows=$allVmViews.Count;DetailedFeatureRows=$detailed.Count;DetailedFeatureLimit=$VmFeatureSampleLimit;Selection='Name then UUID, first N; deterministic'}
  } else {
    $vmCoverage += [pscustomobject]@{vCenter=$vcName;TotalNonTemplateVMs=$allVmViews.Count;EncryptionRows=$allVmViews.Count;DetailedFeatureRows=0;DetailedFeatureLimit=$VmFeatureSampleLimit;Selection='Detailed feature scan skipped; encryption remains exhaustive'}
  }
  Disconnect-VIServer $vc -Confirm:$false -ErrorAction SilentlyContinue
}
Save 'pcli_vcenter.csv' $vcInfo; Save 'pcli_clusters.csv' $clu; Save 'pcli_hosts.csv' $hostHw; Save 'pcli_vmk.csv' $vmk
Save 'pcli_vds.csv' $vds; Save 'pcli_vm_features.csv' $vmf; Save 'pcli_vm_encryption.csv' $vme; Save 'pcli_vm_coverage.csv' $vmCoverage; Save 'pcli_extensions.csv' $ext; Save 'pcli_pci.csv' $pci
Save 'pcli_vsan.csv' $vsan; Save 'pcli_datastores.csv' $ds
Write-Host "Done. Copy the CSV files in $OutDir to the chat together with the RVTools export(s)."
