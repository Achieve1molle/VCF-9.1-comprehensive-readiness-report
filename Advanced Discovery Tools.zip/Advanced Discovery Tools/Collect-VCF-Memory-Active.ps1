<#
.SYNOPSIS
  Read-only capture for memory-tiering sizing: 30-day active-memory history per VM and per host, plus local NVMe devices on each host.
.DESCRIPTION
  RVTools reports ACTIVE memory as a single point-in-time sample, which can miss busy periods. Broadcom guidance is to size tiering from the
  busy-period active memory (keep host active memory at or below 50% of DRAM). This script reads vCenter statistics (mem.active.average) over
  the last N days and writes percentiles, so the report can use the p95 instead of one sample.
  Outputs (CSV, in -OutDir):
    pcli_mem_vm.csv    vCenter, VM, Uuid, ConfiguredGiB, ActiveAvgGiB, ActiveP95GiB, ActiveMaxGiB, SamplesUsed
    pcli_mem_host.csv  vCenter, Host, Cluster, DramGiB, ActiveAvgGiB, ActiveP95GiB, ActiveMaxGiB, TieringType, NvmeTierPct
    pcli_nvme.csv      vCenter, Host, Cluster, Device, Model, SizeGB, IsSsd, IsLocal, IsBoot, Transport   (candidate tier devices; endurance must be checked with the vendor: >= 3 DWPD)
.EXAMPLE
  .\Collect-VcfMemoryActivity.ps1 -VCenter vc1.corp.local,vc2.corp.local -Days 30 -OutDir C:\vcfr
.NOTES
  Requires VMware.PowerCLI 13.x and a read-only vCenter account with Performance.ModifyIntervals NOT required (historical stats read only).
  Historical statistics depend on the vCenter statistics level (level 2 stores mem.active for the 30-day / 5-minute and daily rollups); if a VM
  returns no samples the column is blank and the report falls back to the RVTools sample. Large estates: use -MaxVMs or run per vCenter.
#>
param(
  [Parameter(Mandatory)][string[]]$VCenter,
  [int]$Days = 30,
  [string]$OutDir = ".\vcfr-collect",
  [int]$MaxVMs = 0,                 # 0 = all powered-on VMs
  [switch]$SkipVmStats,             # host stats and NVMe inventory only (fast)
  [pscredential]$Credential
)
$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -Scope Session | Out-Null

function Pct($vals, $p) { if (-not $vals -or $vals.Count -eq 0) { return $null }; $s = $vals | Sort-Object; $i = [math]::Min($s.Count - 1, [math]::Ceiling($p * $s.Count) - 1); return $s[[math]::Max($i, 0)] }
function Save($name, $rows) { if ($rows -and @($rows).Count -gt 0) { $rows | Export-Csv -NoTypeInformation -Path (Join-Path $OutDir $name) -Encoding UTF8; Write-Host ("  wrote {0} ({1} rows)" -f $name, @($rows).Count) } else { Write-Host "  no data for $name" } }

$vmRows = @(); $hostRows = @(); $nvme = @()
$start = (Get-Date).AddDays(-$Days)
foreach ($vcName in $VCenter) {
  Write-Host "== $vcName"
  try { $vc = if ($Credential) { Connect-VIServer $vcName -Credential $Credential -ErrorAction Stop } else { Connect-VIServer $vcName -ErrorAction Stop } } catch { Write-Warning "Cannot connect to $vcName : $_"; continue }

  # ---- hosts: DRAM, current tiering state, active-memory history, local NVMe devices ----
  $hosts = Get-VMHost -Server $vc | Where-Object { $_.ConnectionState -eq 'Connected' }
  foreach ($h in $hosts) {
    $dram = [math]::Round($h.MemoryTotalGB, 1)
    $tt = $null; $pctNv = $null
    try { $tt = $h.ExtensionData.Hardware.MemoryTieringType } catch {}
    try { $pctNv = (Get-AdvancedSetting -Entity $h -Name 'Mem.TierNvmePct' -ErrorAction Stop).Value } catch {}
    $act = @()
    try { $act = @(Get-Stat -Entity $h -Stat 'mem.active.average' -Start $start -IntervalMins 30 -ErrorAction Stop | ForEach-Object { $_.Value / 1MB }) } catch {
      try { $act = @(Get-Stat -Entity $h -Stat 'mem.active.average' -Start $start -ErrorAction Stop | ForEach-Object { $_.Value / 1MB }) } catch {} }
    $hostRows += [pscustomobject]@{vCenter=$vcName;Host=$h.Name;Cluster=$h.Parent.Name;DramGiB=$dram;
        ActiveAvgGiB=$(if($act.Count){[math]::Round(($act | Measure-Object -Average).Average,1)});ActiveP95GiB=$(if($act.Count){[math]::Round((Pct $act 0.95),1)});ActiveMaxGiB=$(if($act.Count){[math]::Round(($act | Measure-Object -Maximum).Maximum,1)});
        TieringType=$tt;NvmeTierPct=$pctNv;Samples=$act.Count}
    try {
      $x = Get-EsxCli -VMHost $h -V2
      foreach ($d in $x.storage.core.device.list.Invoke()) {
        if ($d.IsLocal -eq $true -and $d.DeviceType -ne 'CD-ROM' -and ($d.Model -match 'NVMe|NVME|Intel|Samsung|Micron|Kioxia|KIOXIA|HPE|Dell|PM1|P5|P4|PE|NS' -or $d.Device -like 't10.NVMe*' -or $d.Device -like 'eui.*')) {
          $nvme += [pscustomobject]@{vCenter=$vcName;Host=$h.Name;Cluster=$h.Parent.Name;Device=$d.Device;Model=$d.Model;SizeGB=[math]::Round($d.Size/1024,0);IsSsd=$d.IsSSD;IsLocal=$d.IsLocal;IsBoot=$d.IsBootDevice;Transport=$(if($d.Device -like '*NVMe*'){'NVMe'}else{''})} } }
    } catch { Write-Warning "esxcli failed on $($h.Name): $_" }
  }

  # ---- VMs: active-memory history ----
  if (-not $SkipVmStats) {
    $vms = Get-VM -Server $vc | Where-Object { $_.PowerState -eq 'PoweredOn' -and -not $_.ExtensionData.Config.Template }
    if ($MaxVMs -gt 0) { $vms = $vms | Select-Object -First $MaxVMs }
    $n = 0; $total = @($vms).Count
    foreach ($vm in $vms) {
      $n++; if ($n % 200 -eq 0) { Write-Host ("  VM stats {0}/{1}" -f $n, $total) }
      $act = @()
      try { $act = @(Get-Stat -Entity $vm -Stat 'mem.active.average' -Start $start -IntervalMins 30 -ErrorAction Stop | ForEach-Object { $_.Value / 1MB }) } catch {
        try { $act = @(Get-Stat -Entity $vm -Stat 'mem.active.average' -Start $start -ErrorAction Stop | ForEach-Object { $_.Value / 1MB }) } catch {} }
      $vmRows += [pscustomobject]@{vCenter=$vcName;VM=$vm.Name;Uuid=$vm.ExtensionData.Config.Uuid;ConfiguredGiB=[math]::Round($vm.MemoryGB,1);
          ActiveAvgGiB=$(if($act.Count){[math]::Round(($act | Measure-Object -Average).Average,2)});ActiveP95GiB=$(if($act.Count){[math]::Round((Pct $act 0.95),2)});ActiveMaxGiB=$(if($act.Count){[math]::Round(($act | Measure-Object -Maximum).Maximum,2)});SamplesUsed=$act.Count}
    }
  }
  Disconnect-VIServer $vcName -Confirm:$false -ErrorAction SilentlyContinue
}
Save 'pcli_mem_vm.csv' $vmRows; Save 'pcli_mem_host.csv' $hostRows; Save 'pcli_nvme.csv' $nvme
Write-Host "Done. Hand back pcli_mem_*.csv and pcli_nvme.csv together with the RVTools export."
